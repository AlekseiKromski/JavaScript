var num1 = 12
var num2 = 8


console.log('+ = ', num1 + num2)
console.log('- = ', num1 - num2)
console.log('* = ', num1 * num2)
console.log('/ = ', num1 / num2)
console.log('** = ', num1 ** num2)


var str1 = 'Hellow'
var str2 = 'Zumma'

console.log(' + = ', str1 + ', ' +str2)

console.log(' 1 + 2 = ', 1 + '2')
console.log(' str1 + num1 = ', str1 + num1)

console.log(' boolean + str = ', true + str2)

console.log('true + 1 = ', true + 1) // true = 1 ( 1 + 1 = 2  )
console.log('false + 1 = ', false + 1) // false = 0 ( 0 + 1 = 1 )
