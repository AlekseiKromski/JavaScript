sayHelloTO('Aleksei')

var sayHelloTO = function sayHelloTO (name){
    console.log('Привет, ' , name)
}

function sayHelloTO (name){
    console.log('Привет, ' , name)
}


