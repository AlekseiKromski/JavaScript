var str1 = 'Hello, world'
var str2 = "Hellow world 2"
// Лучше использовать одни ковычки

var personName = 'Viktor'
var message = 'Человека зовут "' + personName +'"'
var message2 = 'Человека зовут \'' + personName + '\' '
var message3 = 'Человека зовут \\  '

console.log(message3)

var newMessage = 'Hello world!!!'

console.log(newMessage.length)
console.log(newMessage.toUpperCase())
console.log(newMessage.charAt(1))
console.log(newMessage.indexOf('world'))
console.log(newMessage.indexOf('dddd'))

console.log(newMessage.substr(6, 5))
console.log(newMessage.indexOf('dddd'))
console.log(newMessage.indexOf('dddd'))