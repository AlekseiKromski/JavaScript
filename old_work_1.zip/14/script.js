var numbers = [1,2,3,4,5]

console.log(numbers[0])

for ( var i = 0; i <= 5; i++ ) {
    console.log(numbers[i]);
}