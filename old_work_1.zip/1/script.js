var message = 'HEllow world!'; 

console.log(message);