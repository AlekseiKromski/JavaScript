console.log('5 > 3', 5 > 3)
console.log('3 < 2', 3 < 2)