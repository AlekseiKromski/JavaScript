console.log( 5 % 2 ) // Деление на цело 
console.log( 8 % 3 ) 
console.log( 15 % 5 ) 

var i = 1
// i = i + 1 // i++
// i = i - 1 // i--
//i += 3 // i = i + 3

console.log("i = ", ++i)

