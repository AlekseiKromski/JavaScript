var number = 23;
var string = 'aaa';
var isTrue  = true; //false
var obj = {a: 1};
var isNull = null;
var undef = undefined;

console.log(typeof isTrue);