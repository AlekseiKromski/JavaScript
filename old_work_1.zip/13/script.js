var person = {
    name: 'Vasili',
    year: 1990,
    family: ['Jelena', 'Igor'],
    car: {
        year: 2010,
        model: 'ford'
    }
}
console.log(person.car.model)