var result = 12 - 6 / 3
var result2 =  3 + 4 * 8
console.log('result =',result)
console.log('result =',result2)

var isGrater = 20 - 6 * 3 >= 4
console.log('result =',isGrater)
